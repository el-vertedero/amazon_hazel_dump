Part01 being a single repeated black frame is intentional, to delay display of animation till mode change completes.
